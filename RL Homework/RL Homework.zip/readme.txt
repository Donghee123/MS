python 3.7.2 버전 테스트 완료

scipy 설치 필요
conda install scipy

test_policy_iteraion_auto_termination.py 실행